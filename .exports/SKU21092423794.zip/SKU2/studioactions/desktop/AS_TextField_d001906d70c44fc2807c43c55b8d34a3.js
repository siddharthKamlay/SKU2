function AS_TextField_d001906d70c44fc2807c43c55b8d34a3(eventobject, changedtext) {
    var self = this;
    return self.filterData.call(this);
}