function AS_ListBox_c927ae555a8444ddb905c8a59c786e27(eventobject) {
    var self = this;
    return self.filterData.call(this);
}